<?php
    echo '
        <h1>Welcome to PHP Motors!</h1>
        <section id="s1">
            <div id="carTitle">
                <div id="carText">
                    <h2 class="ot">DMC Delorean</h2>
                    <p class="ot">3 cup holders</p>
                    <p class="ot">Superman doors</p>
                    <p class="ot">Fuzzy dice!</p>
                    <img id="topOwnToday" class="ownToday" src="images/site/own_today.png" alt="Own today!">
                </div>
                <img id="delorean" src="images/delorean.jpg" alt="Delorean">
                <img id="bottomOwnToday" class="ownToday" src="images/site/own_today.png" alt="Own today!">
            </div>
        </section>
        <section id="s2">
            <table>
                <tr>
                    <th>Delorean Upgrades</th>
                    <th hidden>word</th>
                </tr>
                <tr>
                    <td>
                        <img src="images/upgrades/flux-cap.png" alt="flux-capacitor">
                    </td>
                    <td>
                        <img src="images/upgrades/flame.jpg" alt="flame-decals">
                    </td>
                </tr>
                <tr>
                    <td class="tableATags">
                        <a href="#">Flux Capacitor</a>
                    </td>
                    <td class="tableATags">
                        <a href="#">Flame Decals</a>
                    </td>
                </tr>
                <tr>
                    <td>
                        <img src="images/upgrades/bumper_sticker.jpg" alt="bumper-stickers">
                    </td>
                    <td>
                        <img src="images/upgrades/hub-cap.jpg" alt="hub-caps">
                    </td>
                </tr>
                <tr>
                    <td class="tableATags">
                        <a href="#">Bumper Stickers</a>
                    </td>
                    <td class="tableATags">
                        <a href="#">Hub Caps</a>
                    </td>
                </tr>
            </table>
            <div id="reviewDiv">
                <h3>DMC Delorean Reviews</h3>
                <ul id="reviews">
                    <li>"So fast its almost like traveling in time." (4/5)</li>
                    <li>"Coolest ride on the road." (4/5)</li>
                    <li>"Im feeling Marty McFly!" (5/5)</li>
                    <li>"The most futuristic ride of our day." (5/5)</li>
                    <li>"80s livin and I love it!" (5/5)</li>
                </ul>
            </div>
        </section>'
?>