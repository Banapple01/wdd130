<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Enhancement 1</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
    <link rel="stylesheet" href="css/phpmotors.css" media="screen">
</head>

<body>
    <div id="wrapper">
        <header>
            <img src="images/site/logo.png" alt="PHP Motors">
            <a id="account" href="#">My Account</a>
        </header>
        <nav>
            <ul id="menu">
                <li><a href="#">Home</a></li>
                <li><a href="#">Classic</a></li>
                <li><a href="#">Sports</a></li>
                <li><a href="#">SUV</a></li>
                <li><a href="#">Trucks</a></li>
                <li><a href="#">Used</a></li>
            </ul>
        </nav>
        <main>
            <?php include 'home.php';?>
        </main>
        <hr>
        <footer>
            <span>&copy; PHP Motors, All rights reserved</span>
            <em>All images used are believed to be in "Fair Use". Please notify the author if any are not and they will
                be removed.</em>
            <em>Last Updated: 30 March , 2018</em>
        </footer>
    </div>
</body>

</html>